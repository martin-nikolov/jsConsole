﻿taskName = "";

function Main(bufferElement) {

    SetSolveButton(function () {

    });
}
